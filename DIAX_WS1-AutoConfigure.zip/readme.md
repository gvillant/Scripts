
## Step 1
**Copy to folder Dell_Tools:**
- File after_restore.cmd
- File AutoRestore.xml (check wim name value)
- Folder ProvTool
- Folder AuditMode
 
 ## Step 2
**Copy your custom ppkg and unattend.xml files to the folder ProvTool with the Following names:**
- ProvisioningPackage.ppkg
- unattend.xml
- Add the VMwareWS1ProvisioningTool.msi
