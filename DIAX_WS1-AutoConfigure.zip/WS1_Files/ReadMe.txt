Copy here the following files, respecting their filenames.
- ProvisioningPackage.ppkg       => Your WS1 PPKG
- unattend.xml                   => Your unattend.xml
- VMwareWS1ProvisioningTool.msi  => The WS1 provisioning Tool

Download the WS1 provisioning tool here : https://resources.workspaceone.com/view/r3tpb78l9z8dn6wpjwbt/en
If using Dropship Offline, build and download your custom PPKG and unattend.xml files from your tenant UEM console
If using Dropship Online, download the WS1 generic bundle here : https://resources.workspaceone.com/view/wpjykslvpplktqhsr394/en
